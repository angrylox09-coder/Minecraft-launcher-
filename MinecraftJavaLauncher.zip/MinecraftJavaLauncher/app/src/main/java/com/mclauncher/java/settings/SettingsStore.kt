package com.mclauncher.java.settings

import android.content.Context
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.launcherDs by preferencesDataStore(name = "launcher")

data class LauncherSettings(
    val resolution: String = "854×480",
    val fps: String = "Без ограничений",
    val ramGb: Float = 2f,
    val javaRuntime: String = "Авто",
    val jvmArgs: String = "-Xmx2G",
    val language: String = "Русский",
    val gameDir: String = "",
    val selected: String = "",
    val selectedBuild: String = "",
    val accountType: String = "offline",
    val playerName: String = "Player",
    val msName: String = "",
    val msUuid: String = "",
    val msToken: String = "",
    val msRefresh: String = "",
    val msExpiry: Long = 0L
)

class SettingsStore(private val ctx: Context) {
    private val kRes = stringPreferencesKey("resolution")
    private val kFps = stringPreferencesKey("fps")
    private val kRam = floatPreferencesKey("ram_gb")
    private val kJava = stringPreferencesKey("java_runtime")
    private val kJvm = stringPreferencesKey("jvm_args")
    private val kLang = stringPreferencesKey("language")
    private val kDir = stringPreferencesKey("game_dir")
    private val kSel = stringPreferencesKey("selected")
    private val kBuild = stringPreferencesKey("selected_build")
    private val kType = stringPreferencesKey("account_type")
    private val kName = stringPreferencesKey("player_name")
    private val kMsName = stringPreferencesKey("ms_name")
    private val kMsUuid = stringPreferencesKey("ms_uuid")
    private val kMsToken = stringPreferencesKey("ms_token")
    private val kMsRefresh = stringPreferencesKey("ms_refresh")
    private val kMsExp = longPreferencesKey("ms_expiry")

    val flow: Flow<LauncherSettings> = ctx.launcherDs.data.map { read(it) }

    /** Атомарно читает текущие значения, применяет изменение и записывает обратно. */
    suspend fun update(f: (LauncherSettings) -> LauncherSettings) {
        ctx.launcherDs.edit { p -> write(p, f(read(p))) }
    }

    private fun read(p: Preferences): LauncherSettings {
        val d = LauncherSettings()
        return LauncherSettings(
            resolution = p[kRes] ?: d.resolution,
            fps = p[kFps] ?: d.fps,
            ramGb = p[kRam] ?: d.ramGb,
            javaRuntime = p[kJava] ?: d.javaRuntime,
            jvmArgs = p[kJvm] ?: d.jvmArgs,
            language = p[kLang] ?: d.language,
            gameDir = p[kDir] ?: d.gameDir,
            selected = p[kSel] ?: d.selected,
            selectedBuild = p[kBuild] ?: d.selectedBuild,
            accountType = p[kType] ?: d.accountType,
            playerName = p[kName] ?: d.playerName,
            msName = p[kMsName] ?: d.msName,
            msUuid = p[kMsUuid] ?: d.msUuid,
            msToken = p[kMsToken] ?: d.msToken,
            msRefresh = p[kMsRefresh] ?: d.msRefresh,
            msExpiry = p[kMsExp] ?: d.msExpiry
        )
    }

    private fun write(p: MutablePreferences, s: LauncherSettings) {
        p[kRes] = s.resolution
        p[kFps] = s.fps
        p[kRam] = s.ramGb
        p[kJava] = s.javaRuntime
        p[kJvm] = s.jvmArgs
        p[kLang] = s.language
        p[kDir] = s.gameDir
        p[kSel] = s.selected
        p[kBuild] = s.selectedBuild
        p[kType] = s.accountType
        p[kName] = s.playerName
        p[kMsName] = s.msName
        p[kMsUuid] = s.msUuid
        p[kMsToken] = s.msToken
        p[kMsRefresh] = s.msRefresh
        p[kMsExp] = s.msExpiry
    }
}
