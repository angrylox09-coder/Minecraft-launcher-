package com.mclauncher.java

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.mclauncher.java.ui.LauncherApp
import com.mclauncher.java.ui.McTheme

class MainActivity : ComponentActivity() {
    private val vm: LauncherVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { McTheme { LauncherApp(vm, onExit = { finish() }) } }
    }
}
