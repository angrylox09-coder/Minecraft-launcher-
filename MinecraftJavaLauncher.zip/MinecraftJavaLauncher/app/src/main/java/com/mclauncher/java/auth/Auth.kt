package com.mclauncher.java.auth

import com.mclauncher.java.core.Http
import com.mclauncher.java.core.HttpException
import com.mclauncher.java.launcher.Player
import com.mclauncher.java.settings.LauncherSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URLEncoder
import java.util.UUID

object Accounts {
    private val nameRe = Regex("^[A-Za-z0-9_]{3,16}$")

    fun validName(n: String) = nameRe.matches(n)

    /** Стандартный офлайн-UUID Minecraft: MD5("OfflinePlayer:<ник>"). */
    fun offlineUuid(name: String): String =
        UUID.nameUUIDFromBytes("OfflinePlayer:$name".toByteArray(Charsets.UTF_8)).toString()

    fun offline(s: LauncherSettings) = Player(s.playerName, offlineUuid(s.playerName), "0", "legacy")
}

class DeviceCode(val userCode: String, val url: String, val deviceCode: String, val interval: Int, val expiresIn: Int)

data class MsSession(val name: String, val uuid: String, val token: String, val refresh: String, val expiry: Long)

/**
 * Официальный OAuth 2.0 Device Code Flow Microsoft → Xbox Live → XSTS → Minecraft Services.
 * Пароли не вводятся и не хранятся: пользователь входит на сайте Microsoft.
 * Нужен собственный Azure Client ID (см. README).
 */
object MicrosoftAuth {
    private const val SCOPE = "XboxLive.signin offline_access"
    private const val BASE = "https://login.microsoftonline.com/consumers/oauth2/v2.0"
    private val formHdr = mapOf("Content-Type" to "application/x-www-form-urlencoded")
    private val jsonHdr = mapOf("Content-Type" to "application/json", "Accept" to "application/json")

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun form(vararg p: Pair<String, String>) = p.joinToString("&") { "${enc(it.first)}=${enc(it.second)}" }

    fun start(clientId: String): DeviceCode {
        val j = JSONObject(Http.text("$BASE/devicecode", "POST", formHdr, form("client_id" to clientId, "scope" to SCOPE)))
        return DeviceCode(
            j.getString("user_code"), j.getString("verification_uri"),
            j.getString("device_code"), j.optInt("interval", 5), j.optInt("expires_in", 900)
        )
    }

    suspend fun poll(clientId: String, d: DeviceCode): MsSession = withContext(Dispatchers.IO) {
        val deadline = System.currentTimeMillis() + d.expiresIn * 1000L
        var wait = d.interval * 1000L
        while (System.currentTimeMillis() < deadline) {
            delay(wait)
            var tokenJson: JSONObject? = null
            try {
                tokenJson = JSONObject(
                    Http.text(
                        "$BASE/token", "POST", formHdr,
                        form(
                            "grant_type" to "urn:ietf:params:oauth:grant-type:device_code",
                            "client_id" to clientId,
                            "device_code" to d.deviceCode
                        )
                    )
                )
            } catch (e: HttpException) {
                val err = runCatching { JSONObject(e.body).optString("error") }.getOrDefault("")
                if (err == "slow_down") wait += 5000
                else if (err != "authorization_pending") throw IllegalStateException("Вход отклонён ($err)")
            }
            val tj = tokenJson
            if (tj != null) return@withContext finish(tj.getString("access_token"), tj.optString("refresh_token"))
        }
        throw IllegalStateException("Время ожидания входа истекло")
    }

    suspend fun refresh(clientId: String, refreshToken: String): MsSession = withContext(Dispatchers.IO) {
        val j = JSONObject(
            Http.text(
                "$BASE/token", "POST", formHdr,
                form(
                    "grant_type" to "refresh_token", "client_id" to clientId,
                    "refresh_token" to refreshToken, "scope" to SCOPE
                )
            )
        )
        finish(j.getString("access_token"), j.optString("refresh_token", refreshToken))
    }

    private fun finish(msAccess: String, refresh: String): MsSession {
        val xbl = JSONObject(
            Http.text(
                "https://user.auth.xboxlive.com/user/authenticate", "POST", jsonHdr,
                """{"Properties":{"AuthMethod":"RPS","SiteName":"user.auth.xboxlive.com","RpsTicket":"d=$msAccess"},"RelyingParty":"http://auth.xboxlive.com","TokenType":"JWT"}"""
            )
        )
        val xblToken = xbl.getString("Token")
        val uhs = xbl.getJSONObject("DisplayClaims").getJSONArray("xui").getJSONObject(0).getString("uhs")
        val xsts = JSONObject(
            Http.text(
                "https://xsts.auth.xboxlive.com/xsts/authorize", "POST", jsonHdr,
                """{"Properties":{"SandboxId":"RETAIL","UserTokens":["$xblToken"]},"RelyingParty":"rp://api.minecraftservices.com/","TokenType":"JWT"}"""
            )
        ).getString("Token")
        val mc = JSONObject(
            Http.text(
                "https://api.minecraftservices.com/authentication/login_with_xbox", "POST", jsonHdr,
                """{"identityToken":"XBL3.0 x=$uhs;$xsts"}"""
            )
        )
        val token = mc.getString("access_token")
        val expires = mc.optLong("expires_in", 86400L)
        val prof = JSONObject(
            Http.text(
                "https://api.minecraftservices.com/minecraft/profile", "GET",
                mapOf("Authorization" to "Bearer $token")
            )
        )
        return MsSession(
            prof.getString("name"), prof.getString("id"), token, refresh,
            System.currentTimeMillis() + expires * 1000L - 60_000L
        )
    }
}
