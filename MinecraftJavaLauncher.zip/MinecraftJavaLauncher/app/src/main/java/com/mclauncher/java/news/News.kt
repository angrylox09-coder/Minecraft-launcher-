package com.mclauncher.java.news

import com.mclauncher.java.core.Config
import com.mclauncher.java.core.Http
import org.json.JSONObject
import java.io.File

data class NewsItem(val title: String, val date: String, val version: String, val image: String, val url: String)

/** Настоящие патчноуты из официального фида Mojang (launchercontent.mojang.com). */
object NewsRepo {
    fun fetch(cache: File): List<NewsItem> {
        val text = try {
            Http.text(Config.NEWS_URL).also { cache.writeText(it) }
        } catch (e: Exception) {
            if (cache.exists()) cache.readText() else throw e
        }
        val arr = JSONObject(text).getJSONArray("entries")
        val out = mutableListOf<NewsItem>()
        for (i in 0 until arr.length()) {
            val e = arr.getJSONObject(i)
            val img = e.optJSONObject("image")?.optString("url").orEmpty()
            val ver = e.optString("version")
            out += NewsItem(
                title = e.optString("title").ifEmpty { "Minecraft $ver" },
                date = e.optString("date").take(10),
                version = ver,
                image = if (img.startsWith("/")) Config.NEWS_HOST + img else img,
                url = "https://minecraft.wiki/w/Java_Edition_$ver"
            )
        }
        return out.sortedByDescending { it.date }.take(25)
    }

    fun prettyDate(d: String): String {
        val p = d.split("-")
        return if (p.size == 3) "${p[2]}.${p[1]}.${p[0]}" else d
    }
}
