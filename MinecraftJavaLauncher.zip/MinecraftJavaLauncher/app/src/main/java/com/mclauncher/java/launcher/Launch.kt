package com.mclauncher.java.launcher

import android.content.Context
import com.mclauncher.java.core.VersionJson
import com.mclauncher.java.settings.LauncherSettings
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Player(val name: String, val uuid: String, val token: String, val type: String)

data class LaunchPlan(
    val workDir: File,
    val javaArgs: List<String>,
    val mainClass: String,
    val gameArgs: List<String>
) {
    fun commandLine(javaBin: String = "java"): String =
        (listOf(javaBin) + javaArgs + mainClass + gameArgs)
            .joinToString(" ") { if (it.contains(' ')) "\"$it\"" else it }
}

/**
 * Рантайм-бэкенд: то, что реально исполняет JVM с графическим мостом (OpenGL/GLFW) на Android.
 * См. docs/RUNTIME_INTEGRATION.md. В этой сборке бэкендов нет — поэтому «ИГРАТЬ» честно сообщает об этом.
 */
interface RuntimeBackend {
    val name: String
    fun isAvailable(context: Context): Boolean
    fun launch(context: Context, plan: LaunchPlan, javaRuntime: String)
}

object Runtimes {
    /** Сюда регистрируются реальные бэкенды (Pojav-совместимый рантайм). */
    val backends: List<RuntimeBackend> = emptyList()

    fun available(ctx: Context): RuntimeBackend? = backends.firstOrNull { it.isAvailable(ctx) }
}

/** Строит настоящую командную строку запуска из version.json (classpath, JVM/игровые аргументы). */
object LaunchCommand {

    fun build(gameDir: File, workDir: File, id: String, player: Player, s: LauncherSettings): LaunchPlan {
        val v = VersionJson.load(gameDir, id)
        val jarId = VersionJson.jarId(v, id)
        val libs = VersionJson.libraries(v).map { File(gameDir, "libraries/${it.path}") }
        val missing = libs.count { !it.exists() }
        if (missing > 0) error("Не хватает файлов библиотек: $missing. Переустановите версию.")
        val clientJar = File(gameDir, "versions/$jarId/$jarId.jar")
        if (!clientJar.exists()) error("Нет клиента $jarId.jar. Переустановите версию.")
        val cp = (libs + clientJar).joinToString(":") { it.path }

        val parts = s.resolution.split("×")
        val w = parts.getOrNull(0) ?: "854"
        val h = parts.getOrNull(1) ?: "480"
        workDir.mkdirs()
        applyFps(workDir, s.fps)

        val assetsIdx = v.optJSONObject("assetIndex")?.optString("id") ?: v.optString("assets", "legacy")
        val natives = File(gameDir, "natives/$id").path
        val vars = mapOf(
            "auth_player_name" to player.name,
            "version_name" to id,
            "game_directory" to workDir.path,
            "assets_root" to File(gameDir, "assets").path,
            "game_assets" to File(gameDir, "assets/virtual/legacy").path,
            "assets_index_name" to assetsIdx,
            "auth_uuid" to player.uuid,
            "auth_access_token" to player.token,
            "clientid" to "",
            "auth_xuid" to "",
            "user_type" to player.type,
            "version_type" to v.optString("type", "release"),
            "resolution_width" to w,
            "resolution_height" to h,
            "natives_directory" to natives,
            "launcher_name" to "MinecraftJavaLauncher",
            "launcher_version" to "1.0.0",
            "classpath" to cp,
            "classpath_separator" to ":",
            "library_directory" to File(gameDir, "libraries").path,
            "user_properties" to "{}"
        )

        val args = v.optJSONObject("arguments")
        val jvmFromJson = resolve(args?.optJSONArray("jvm"), vars)
        val jvm = if (jvmFromJson.isNotEmpty()) jvmFromJson
        else listOf("-Djava.library.path=$natives", "-cp", cp)

        val game = if (args != null) resolve(args.optJSONArray("game"), vars)
        else v.optString("minecraftArguments").split(" ").filter { it.isNotBlank() }.map { sub(it, vars) }

        val user = s.jvmArgs.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        val xmx = if (user.any { it.startsWith("-Xmx") }) emptyList()
        else listOf("-Xmx${(s.ramGb * 1024).toInt()}M")

        return LaunchPlan(workDir, xmx + user + jvm, v.getString("mainClass"), game)
    }

    private fun resolve(arr: JSONArray?, vars: Map<String, String>): List<String> {
        val out = mutableListOf<String>()
        if (arr == null) return out
        for (i in 0 until arr.length()) {
            val e = arr.get(i)
            if (e is String) {
                out += sub(e, vars)
            } else if (e is JSONObject) {
                if (!VersionJson.rulesAllow(e.optJSONArray("rules"))) continue
                when (val value = e.get("value")) {
                    is String -> out += sub(value, vars)
                    is JSONArray -> for (j in 0 until value.length()) out += sub(value.getString(j), vars)
                }
            }
        }
        return out
    }

    private fun sub(s: String, vars: Map<String, String>): String =
        Regex("\\$\\{(\\w+)}").replace(s) { vars[it.groupValues[1]] ?: it.value }

    /** Лимит FPS реально применяется через options.txt игры (260 = без ограничений). */
    private fun applyFps(workDir: File, fps: String) {
        val value = fps.toIntOrNull() ?: 260
        val f = File(workDir, "options.txt")
        val lines = if (f.exists()) f.readLines().toMutableList() else mutableListOf()
        val i = lines.indexOfFirst { it.startsWith("maxFps:") }
        if (i >= 0) lines[i] = "maxFps:$value" else lines += "maxFps:$value"
        f.writeText(lines.joinToString("\n") + "\n")
    }
}
