package com.mclauncher.java.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mclauncher.java.LauncherVM
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.receiveAsFlow

enum class Screen { Home, Versions, Mods, Settings, Account, News, Builds, More }

@Composable
fun LauncherApp(vm: LauncherVM, onExit: () -> Unit) {
    var screen by rememberSaveable { mutableStateOf(Screen.Home) }
    var splash by rememberSaveable { mutableStateOf(true) }
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val dlg by vm.dialog.collectAsStateWithLifecycle()

    BackHandler(enabled = screen != Screen.Home) { screen = Screen.Home }
    LaunchedEffect(Unit) {
        vm.messages.receiveAsFlow().collect { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show() }
    }
    LaunchedEffect(Unit) {
        delay(1100)
        splash = false
    }

    Box(Modifier.fillMaxSize().background(Mc.Bg)) {
        AnimatedContent(
            targetState = screen,
            transitionSpec = {
                if (targetState != Screen.Home)
                    (slideInHorizontally { it / 3 } + fadeIn()) togetherWith (slideOutHorizontally { -it / 6 } + fadeOut())
                else
                    (slideInHorizontally { -it / 6 } + fadeIn()) togetherWith (slideOutHorizontally { it / 3 } + fadeOut())
            },
            label = "nav"
        ) { sc ->
            val back = { screen = Screen.Home }
            when (sc) {
                Screen.Home -> HomeScreen(vm) { screen = it }
                Screen.Versions -> VersionsScreen(vm, back)
                Screen.Mods -> ModsScreen(vm, back)
                Screen.Settings -> SettingsScreen(vm, back)
                Screen.Account -> AccountScreen(vm, back)
                Screen.News -> NewsScreen(vm, back)
                Screen.Builds -> BuildsScreen(vm, back)
                Screen.More -> MoreScreen(vm, back, onExit)
            }
        }

        AnimatedVisibility(splash, enter = fadeIn(), exit = fadeOut(tween(400))) { Splash() }

        dlg?.let { d ->
            AlertDialog(
                onDismissRequest = { vm.dialog.value = null },
                containerColor = Mc.Card,
                title = { Text(d.title, color = Color.White) },
                text = {
                    Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                        Text(d.text, color = Mc.Dim)
                        if (d.command != null) {
                            Spacer(Modifier.height(10.dp))
                            SelectionContainer {
                                Text(
                                    d.command, color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
                                        .background(Mc.Bg).padding(8.dp)
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Row {
                        if (d.command != null) {
                            TextButton(onClick = { clip.setText(AnnotatedString(d.command)) }) {
                                Text("Копировать", color = Mc.Green)
                            }
                        }
                        if (d.url != null) {
                            TextButton(onClick = { vm.openUrl(d.url); vm.dialog.value = null }) {
                                Text("Открыть", color = Mc.Green)
                            }
                        }
                        TextButton(onClick = { vm.dialog.value = null }) { Text("Закрыть", color = Mc.Green) }
                    }
                }
            )
        }
    }
}

@Composable
private fun Splash() {
    val t = rememberInfiniteTransition(label = "splash")
    val sc by t.animateFloat(0.9f, 1.08f, infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "scale")
    Column(
        Modifier.fillMaxSize().background(Mc.Bg),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CreeperFace(Modifier.size(96.dp).scale(sc).clip(RoundedCornerShape(14.dp)))
        Spacer(Modifier.height(18.dp))
        Text("Minecraft", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Java Launcher", color = Mc.Dim, fontSize = 16.sp)
        Spacer(Modifier.height(26.dp))
        LoadingBar(0.65f, Modifier.width(160.dp))
    }
}
