package com.mclauncher.java.core

import android.content.Context
import com.mclauncher.java.BuildConfig
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

object Config {
    const val VERSION_MANIFEST = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
    const val ASSET_BASE = "https://resources.download.minecraft.net"
    const val NEWS_URL = "https://launchercontent.mojang.com/v2/javaPatchNotes.json"
    const val NEWS_HOST = "https://launchercontent.mojang.com"
    const val MODRINTH = "https://api.modrinth.com/v2"
    const val FABRIC_META = "https://meta.fabricmc.net/v2"

    /** Замените на свой инвайт-ссылку Discord-сервера. */
    const val DISCORD_URL = "https://discord.com"

    val repo: String get() = BuildConfig.GITHUB_REPO
    val supportUrl: String get() = "https://github.com/$repo/issues"
}

class HttpException(val code: Int, val body: String) : IOException("HTTP $code")

object Http {
    private const val UA = "MinecraftJavaLauncher/1.0"

    private fun open(
        url: String,
        method: String = "GET",
        headers: Map<String, String> = emptyMap(),
        body: String? = null
    ): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 30_000
        c.requestMethod = method
        c.setRequestProperty("User-Agent", UA)
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (body != null) {
            c.doOutput = true
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        return c
    }

    fun text(
        url: String,
        method: String = "GET",
        headers: Map<String, String> = emptyMap(),
        body: String? = null
    ): String {
        val c = open(url, method, headers, body)
        try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw HttpException(code, text)
            return text
        } finally {
            c.disconnect()
        }
    }

    fun bytes(url: String): ByteArray {
        val c = open(url)
        try {
            if (c.responseCode !in 200..299) throw HttpException(c.responseCode, url)
            return c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }

    /** Скачивает файл во временный .part, проверяет SHA-1 (если задан) и переименовывает. */
    fun download(url: String, dest: File, sha1: String? = null) {
        dest.parentFile?.mkdirs()
        val tmp = File(dest.path + ".part")
        val c = open(url)
        try {
            if (c.responseCode !in 200..299) throw HttpException(c.responseCode, url)
            val md = MessageDigest.getInstance("SHA-1")
            c.inputStream.use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        md.update(buf, 0, n)
                    }
                }
            }
            if (!sha1.isNullOrBlank()) {
                val hex = md.digest().joinToString("") { "%02x".format(it) }
                if (!hex.equals(sha1, ignoreCase = true)) {
                    tmp.delete()
                    throw IOException("Контрольная сумма не совпала: $url")
                }
            }
            if (dest.exists()) dest.delete()
            if (!tmp.renameTo(dest)) throw IOException("Не удалось записать ${dest.path}")
        } finally {
            c.disconnect()
        }
    }
}

object Paths {
    fun defaultGameDir(ctx: Context): File =
        File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "minecraft")

    fun gameDir(ctx: Context, custom: String): File =
        if (custom.isBlank()) defaultGameDir(ctx) else File(custom)
}
