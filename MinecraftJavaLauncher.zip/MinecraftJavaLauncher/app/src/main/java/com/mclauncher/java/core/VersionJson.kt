package com.mclauncher.java.core

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class LibFile(val path: String, val url: String, val sha1: String, val size: Long)

/** Чтение version.json с учётом inheritsFrom (Fabric/Forge-профили) и правил Mojang. */
object VersionJson {

    fun load(gameDir: File, id: String): JSONObject {
        val raw = JSONObject(File(gameDir, "versions/$id/$id.json").readText())
        val parentId = raw.optString("inheritsFrom")
        if (parentId.isEmpty()) return raw
        val parent = load(gameDir, parentId)
        val merged = JSONObject(parent.toString())
        for (k in raw.keys()) {
            when (k) {
                "libraries" -> {
                    val arr = JSONArray()
                    raw.getJSONArray(k).let { a -> for (i in 0 until a.length()) arr.put(a.get(i)) }
                    parent.optJSONArray(k)?.let { a -> for (i in 0 until a.length()) arr.put(a.get(i)) }
                    merged.put(k, arr)
                }
                "arguments" -> merged.put(k, mergeArgs(parent.optJSONObject(k), raw.getJSONObject(k)))
                else -> merged.put(k, raw.get(k))
            }
        }
        return merged
    }

    private fun mergeArgs(p: JSONObject?, c: JSONObject): JSONObject {
        val out = JSONObject()
        for (key in listOf("jvm", "game")) {
            val arr = JSONArray()
            p?.optJSONArray(key)?.let { a -> for (i in 0 until a.length()) arr.put(a.get(i)) }
            c.optJSONArray(key)?.let { a -> for (i in 0 until a.length()) arr.put(a.get(i)) }
            out.put(key, arr)
        }
        return out
    }

    fun jarId(merged: JSONObject, id: String): String =
        merged.optString("jar").ifEmpty { merged.optString("inheritsFrom").ifEmpty { id } }

    /** Правила Mojang: побеждает последнее подходящее правило. ОС = linux, архитектура — не x86. */
    fun rulesAllow(rules: JSONArray?, features: Set<String> = emptySet()): Boolean {
        if (rules == null || rules.length() == 0) return true
        var allowed = false
        for (i in 0 until rules.length()) {
            val r = rules.getJSONObject(i)
            var match = true
            r.optJSONObject("os")?.let { os ->
                val name = os.optString("name")
                if ((name.isNotEmpty() && name != "linux") || os.has("arch")) match = false
            }
            r.optJSONObject("features")?.let { f ->
                for (k in f.keys()) if (f.optBoolean(k) != (k in features)) match = false
            }
            if (match) allowed = r.optString("action") == "allow"
        }
        return allowed
    }

    fun mavenPath(name: String): String? {
        val p = name.split(":")
        if (p.size < 3) return null
        val cls = if (p.size > 3) "-${p[3]}" else ""
        return "${p[0].replace('.', '/')}/${p[1]}/${p[2]}/${p[1]}-${p[2]}$cls.jar"
    }

    /**
     * Список библиотек для загрузки и classpath. Нативные linux-x86 библиотеки (":natives-")
     * пропускаются: на Android их заменяет рантайм (LWJGL от Pojav-совместимого движка).
     */
    fun libraries(merged: JSONObject): List<LibFile> {
        val out = mutableListOf<LibFile>()
        val libs = merged.optJSONArray("libraries") ?: return out
        for (i in 0 until libs.length()) {
            val l = libs.getJSONObject(i)
            if (!rulesAllow(l.optJSONArray("rules"))) continue
            val name = l.optString("name")
            if (name.contains(":natives-")) continue
            val art = l.optJSONObject("downloads")?.optJSONObject("artifact")
            if (art != null) {
                out += LibFile(art.getString("path"), art.getString("url"), art.optString("sha1"), art.optLong("size"))
                continue
            }
            if (l.has("downloads")) continue // только classifiers (natives)
            val path = mavenPath(name) ?: continue
            val base = l.optString("url", "https://libraries.minecraft.net/")
            out += LibFile(path, base.trimEnd('/') + "/" + path, "", 0L)
        }
        return out
    }
}
