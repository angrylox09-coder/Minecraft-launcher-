package com.mclauncher.java.builds

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Build(
    val id: String,
    val name: String,
    val desc: String,
    val mc: String,
    val loader: String,          // "vanilla" | "fabric" | "forge"
    val mods: List<String>,      // слаги Modrinth, ставятся при установке
    val custom: Boolean = false,
    val versionId: String = ""   // id версии для запуска (ванильная или fabric-профиль)
)

object BuildCatalog {
    val all = listOf(
        Build("vanilla-plus", "Vanilla+", "Улучшенный ванильный опыт", "1.21.1", "fabric",
            listOf("sodium", "lithium", "iris")),
        Build("technomagic", "TechnoMagic", "Техномагический мир", "1.20.1", "forge", emptyList()),
        Build("skyblock", "SkyBlock", "Выживание на острове", "1.20.1", "fabric", emptyList()),
        Build("rlcraft", "RLCraft", "Сложный выживач", "1.12.2", "forge", emptyList())
    )
}

/** Сборка = изолированная папка instances/<id> со своими mods, saves, options.txt и build.json. */
class BuildsRepo(private val gameDir: File) {
    fun dir(id: String) = File(gameDir, "instances/$id")

    fun list(): List<Build> =
        File(gameDir, "instances").listFiles()?.mapNotNull { d ->
            val f = File(d, "build.json")
            if (!f.exists()) null else runCatching { fromJson(JSONObject(f.readText())) }.getOrNull()
        } ?: emptyList()

    fun save(b: Build) {
        val d = dir(b.id)
        File(d, "mods").mkdirs()
        val j = JSONObject()
            .put("id", b.id).put("name", b.name).put("desc", b.desc)
            .put("mc", b.mc).put("loader", b.loader).put("versionId", b.versionId)
            .put("custom", b.custom).put("mods", JSONArray(b.mods))
        File(d, "build.json").writeText(j.toString())
    }

    fun remove(id: String) {
        dir(id).deleteRecursively()
    }

    private fun fromJson(j: JSONObject): Build {
        val m = j.optJSONArray("mods")
        val mods = (0 until (m?.length() ?: 0)).map { m!!.getString(it) }
        return Build(
            j.getString("id"), j.getString("name"), j.optString("desc"), j.getString("mc"),
            j.optString("loader", "vanilla"), mods, j.optBoolean("custom"), j.optString("versionId")
        )
    }
}
