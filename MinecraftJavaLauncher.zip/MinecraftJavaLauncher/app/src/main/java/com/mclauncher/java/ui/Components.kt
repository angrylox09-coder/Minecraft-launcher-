package com.mclauncher.java.ui

import android.graphics.BitmapFactory
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mclauncher.java.core.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

object Mc {
    val Bg = Color(0xFF080A08)
    val Card = Color(0xFF171A17)
    val Green = Color(0xFF39E52F)
    val GreenDark = Color(0xFF1D9B25)
    val Dim = Color(0xFFA0A0A0)
    val Line = Color(0xFF2A2E2A)
    val Warn = Color(0xFFFFB300)
}

@Composable
fun McTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Mc.Green, onPrimary = Color.Black,
            secondary = Mc.GreenDark, background = Mc.Bg, onBackground = Color.White,
            surface = Mc.Card, onSurface = Color.White,
            surfaceVariant = Mc.Card, onSurfaceVariant = Mc.Dim
        ),
        content = content
    )
}

fun Modifier.card(): Modifier = this.clip(RoundedCornerShape(16.dp)).background(Mc.Card)

@Composable
fun McButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    big: Boolean = false,
    leading: (@Composable () -> Unit)? = null
) {
    val shape = RoundedCornerShape(if (big) 14.dp else 12.dp)
    Row(
        modifier
            .height(if (big) 58.dp else 50.dp)
            .alpha(if (enabled) 1f else 0.45f)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Mc.Green, Mc.GreenDark)))
            .clickable(enabled = enabled, onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (leading != null) {
            leading()
            Spacer(Modifier.width(8.dp))
        }
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = if (big) 22.sp else 17.sp)
    }
}

@Composable
fun OutlineBtn(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    val shape = RoundedCornerShape(8.dp)
    Box(
        modifier
            .alpha(if (enabled) 1f else 0.45f)
            .clip(shape)
            .background(Mc.Bg)
            .border(1.5.dp, Mc.Green, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Mc.Green, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
fun TopBar(title: String, onBack: () -> Unit, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад", tint = Color.White)
        }
        Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        actions()
    }
}

@Composable
fun Tabs(items: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEachIndexed { i, t ->
            val shape = RoundedCornerShape(10.dp)
            val sel = i == selected
            Box(
                Modifier.weight(1f).height(44.dp).clip(shape)
                    .then(
                        if (sel) Modifier.background(Brush.verticalGradient(listOf(Mc.Green, Mc.GreenDark)))
                        else Modifier.background(Mc.Card)
                    )
                    .clickable { onSelect(i) },
                contentAlignment = Alignment.Center
            ) {
                Text(t, color = if (sel) Color.White else Mc.Dim, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape)
            .background(if (selected) Mc.GreenDark else Mc.Card)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp)
    ) {
        Text(text, color = if (selected) Color.White else Mc.Dim, fontSize = 13.sp)
    }
}

@Composable
fun McField(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, label: String? = null) {
    OutlinedTextField(
        value = value, onValueChange = onChange, modifier = modifier, singleLine = true,
        label = if (label != null) ({ Text(label) }) else null,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Mc.Green, unfocusedBorderColor = Mc.Line,
            cursorColor = Mc.Green, focusedLabelColor = Mc.Green,
            focusedTextColor = Color.White, unfocusedTextColor = Color.White
        )
    )
}

@Composable
fun DropRow(label: String, value: String, options: List<String>, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        Row(
            Modifier.fillMaxWidth().clickable { open = true }.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Text(value, color = Mc.Dim, fontSize = 15.sp)
            Text("  ▾", color = Mc.Dim)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o ->
                DropdownMenuItem(text = { Text(o) }, onClick = { onSelect(o); open = false })
            }
        }
    }
}

@Composable
fun Section(title: String, glyph: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().card()) {
        Row(
            Modifier.fillMaxWidth().background(Color(0xFF1E221E)).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(glyph, fontSize = 20.sp)
            Spacer(Modifier.width(10.dp))
            Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
        content()
    }
}

/** Анимированная полоса загрузки: заполнение + бегущий блик. */
@Composable
fun LoadingBar(fraction: Float, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "load")
    val shift by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "shift")
    val f by animateFloatAsState(fraction.coerceIn(0f, 1f), label = "fraction")
    Box(modifier.height(10.dp).clip(RoundedCornerShape(5.dp)).background(Mc.Line)) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width * f
            drawRect(Brush.horizontalGradient(listOf(Mc.GreenDark, Mc.Green)), size = Size(w, size.height))
            val sx = (w + 60f) * shift - 60f
            clipRect(0f, 0f, w, size.height) {
                drawRect(Color.White.copy(alpha = 0.28f), Offset(sx, 0f), Size(40f, size.height))
            }
        }
    }
}

// ---------- пиксельные иконки, нарисованные кодом (без внешних ресурсов) ----------

@Composable
fun Grass(dp: Dp, modifier: Modifier = Modifier) {
    val top = listOf(Color(0xFF5FB336), Color(0xFF4F9E2C), Color(0xFF6CC441), Color(0xFF57A830))
    val dirt = listOf(Color(0xFF8A5A33), Color(0xFF7A4E2B), Color(0xFF96653C), Color(0xFF6E4527))
    Canvas(modifier.size(dp).clip(RoundedCornerShape(dp / 8))) {
        val n = 8
        val c = this.size.width / n
        for (y in 0 until n) for (x in 0 until n) {
            val r = (x * 7 + y * 13 + x * y) % 4
            drawRect(if (y < 3) top[r] else dirt[r], Offset(x * c, y * c), Size(c + 0.5f, c + 0.5f))
        }
    }
}

private val creeper = listOf(
    "........", "........", ".##..##.", ".##..##.",
    "...##...", "..####..", "..####..", "..#..#.."
)

@Composable
fun CreeperFace(modifier: Modifier = Modifier) {
    val greens = listOf(Color(0xFF39E52F), Color(0xFF2FC727), Color(0xFF47F23C))
    Canvas(modifier) {
        val c = size.width / 8
        for (y in 0 until 8) for (x in 0 until 8) {
            val dark = creeper[y][x] == '#'
            drawRect(
                if (dark) Color(0xFF0B2B0A) else greens[(x * 5 + y * 3) % 3],
                Offset(x * c, y * c), Size(c + 0.5f, c + 0.5f)
            )
        }
    }
}

@Composable
fun SkinHead(skin: ImageBitmap?, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val dst = IntSize(size.width.roundToInt(), size.height.roundToInt())
        if (skin != null) {
            drawImage(skin, IntOffset(8, 8), IntSize(8, 8), IntOffset.Zero, dst, filterQuality = FilterQuality.None)
            drawImage(skin, IntOffset(40, 8), IntSize(8, 8), IntOffset.Zero, dst, filterQuality = FilterQuality.None)
        } else {
            drawRect(Color(0xFFC99674))
            drawRect(Color(0xFF4A3220), size = Size(size.width, size.height * 0.35f))
            drawRect(Color(0xFF3A3A9A), Offset(size.width * 0.12f, size.height * 0.5f), Size(size.width * 0.25f, size.height * 0.12f))
            drawRect(Color(0xFF3A3A9A), Offset(size.width * 0.63f, size.height * 0.5f), Size(size.width * 0.25f, size.height * 0.12f))
        }
    }
}

/** Вид спереди: из PNG-скина вырезаются голова, тело, руки и ноги. Без скина — Стив, нарисованный кодом. */
@Composable
fun SkinPreview(skin: ImageBitmap?, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.height / 32f
        val ox = (size.width - 16 * u) / 2
        fun part(sx: Int, sy: Int, w: Int, h: Int, dx: Int, dy: Int) {
            if (skin == null) return
            drawImage(
                skin, IntOffset(sx, sy), IntSize(w, h),
                IntOffset((ox + dx * u).roundToInt(), (dy * u).roundToInt()),
                IntSize((w * u).roundToInt(), (h * u).roundToInt()),
                filterQuality = FilterQuality.None
            )
        }
        fun rect(c: Color, x: Int, y: Int, w: Int, h: Int) =
            drawRect(c, Offset(ox + x * u, y * u), Size(w * u, h * u))
        if (skin == null) {
            val skinC = Color(0xFFC99674)
            rect(skinC, 4, 0, 8, 8); rect(Color(0xFF4A3220), 4, 0, 8, 3)
            rect(Color(0xFF3A3A9A), 5, 4, 2, 1); rect(Color(0xFF3A3A9A), 9, 4, 2, 1)
            rect(Color(0xFF00A8A8), 4, 8, 8, 12)
            rect(skinC, 0, 8, 4, 12); rect(skinC, 12, 8, 4, 12)
            rect(Color(0xFF3B3B9C), 4, 20, 4, 12); rect(Color(0xFF3B3B9C), 8, 20, 4, 12)
        } else {
            part(8, 8, 8, 8, 4, 0); part(40, 8, 8, 8, 4, 0)
            part(20, 20, 8, 12, 4, 8)
            part(44, 20, 4, 12, 0, 8); part(44, 20, 4, 12, 12, 8)
            part(4, 20, 4, 12, 4, 20); part(4, 20, 4, 12, 8, 20)
        }
    }
}

@Composable
fun CapePreview(cape: ImageBitmap?, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        if (cape == null) {
            drawRect(Color(0xFF1E221E), size = size)
        } else {
            drawImage(
                cape, IntOffset(1, 1), IntSize(10, 16), IntOffset.Zero,
                IntSize(size.width.roundToInt(), size.height.roundToInt()), filterQuality = FilterQuality.None
            )
        }
    }
}

private val imgCache = object : android.util.LruCache<String, ImageBitmap>(24) {}

@Composable
fun RemoteImage(url: String, modifier: Modifier = Modifier) {
    val img by produceState<ImageBitmap?>(imgCache.get(url), url) {
        if (value == null) {
            value = withContext(Dispatchers.IO) {
                runCatching {
                    val bytes = Http.bytes(url)
                    val o = BitmapFactory.Options().apply { inSampleSize = 2 }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)?.asImageBitmap()
                        ?.also { imgCache.put(url, it) }
                }.getOrNull()
            }
        }
    }
    val b = img
    if (b != null) Image(bitmap = b, contentDescription = null, modifier = modifier, contentScale = ContentScale.Crop)
    else Box(modifier.background(Mc.Line))
}
