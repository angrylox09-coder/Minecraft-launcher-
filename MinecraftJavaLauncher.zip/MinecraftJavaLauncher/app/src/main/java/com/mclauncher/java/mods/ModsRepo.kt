package com.mclauncher.java.mods

import com.mclauncher.java.core.Config
import com.mclauncher.java.core.Http
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder

enum class ModKind { FABRIC, MODRINTH, WEBSITE }

data class ModEntry(
    val id: String,
    val name: String,
    val desc: String,
    val glyph: String,
    val kind: ModKind,
    val slug: String = "",
    val url: String = ""
)

object ModCatalog {
    val all = listOf(
        ModEntry("fabric", "Fabric", "Лёгкий модлоадер", "🧵", ModKind.FABRIC),
        ModEntry("forge", "Forge", "Мощный модлоадер (установщик — на сайте)", "🔨", ModKind.WEBSITE,
            url = "https://files.minecraftforge.net/net/minecraftforge/forge/"),
        ModEntry("neoforge", "NeoForge", "Современный форк Forge (установщик — на сайте)", "🦊", ModKind.WEBSITE,
            url = "https://neoforged.net/"),
        ModEntry("optifine", "OptiFine", "Оптимизация графики (лицензия: только с сайта)", "🔆", ModKind.WEBSITE,
            url = "https://optifine.net/downloads"),
        ModEntry("sodium", "Sodium", "Быстрый движок отрисовки (Fabric)", "💎", ModKind.MODRINTH, slug = "sodium"),
        ModEntry("iris", "Iris", "Шейдеры для Sodium (Fabric)", "🌈", ModKind.MODRINTH, slug = "iris"),
        ModEntry("xaero", "Xaero's Minimap", "Миникарта (Fabric)", "🗺️", ModKind.MODRINTH, slug = "xaeros-minimap"),
        ModEntry("jei", "JEI", "Просмотр рецептов (Fabric)", "ℹ️", ModKind.MODRINTH, slug = "jei")
    )
}

/**
 * Моды лежат в <workDir>/mods. Учёт ведётся в .launcher-mods.json; мод считается
 * установленным только если запись есть И файл реально существует на диске.
 */
class ModsRepo(private val workDir: File) {
    private val modsDir get() = File(workDir, "mods")
    private val record get() = File(modsDir, ".launcher-mods.json")

    private fun readRecord(): JSONObject =
        runCatching { JSONObject(record.readText()) }.getOrDefault(JSONObject())

    private fun saveRecord(r: JSONObject) {
        modsDir.mkdirs()
        record.writeText(r.toString())
    }

    fun installed(): Map<String, String> {
        val r = readRecord()
        val out = linkedMapOf<String, String>()
        for (k in r.keys()) {
            val fn = r.getString(k)
            if (File(modsDir, fn).exists()) out[k] = fn
        }
        return out
    }

    fun remove(key: String) {
        val r = readRecord()
        val fn = r.optString(key)
        if (fn.isNotEmpty()) File(modsDir, fn).delete()
        r.remove(key)
        saveRecord(r)
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** Ставит мод с Modrinth (последняя совместимая версия) вместе с обязательными зависимостями. */
    fun installModrinth(recordKey: String, project: String, mc: String, loader: String, depth: Int = 0) {
        val q = "game_versions=" + enc("[\"$mc\"]") + "&loaders=" + enc("[\"$loader\"]")
        val versions = JSONArray(Http.text("${Config.MODRINTH}/project/$project/version?$q"))
        if (versions.length() == 0) error("Для Minecraft $mc ($loader) нет версии «$project»")
        val v = versions.getJSONObject(0)

        val deps = v.optJSONArray("dependencies")
        if (deps != null && depth < 3) {
            for (i in 0 until deps.length()) {
                val d = deps.getJSONObject(i)
                if (d.optString("dependency_type") != "required" || d.isNull("project_id")) continue
                val pid = d.getString("project_id")
                if (installed().containsKey(pid)) continue
                installModrinth(pid, pid, mc, loader, depth + 1)
            }
        }

        val files = v.getJSONArray("files")
        var f = files.getJSONObject(0)
        for (i in 0 until files.length()) {
            if (files.getJSONObject(i).optBoolean("primary")) f = files.getJSONObject(i)
        }
        val name = f.getString("filename")
        modsDir.mkdirs()
        Http.download(f.getString("url"), File(modsDir, name), f.optJSONObject("hashes")?.optString("sha1"))
        val r = readRecord()
        r.put(recordKey, name)
        saveRecord(r)
    }
}
