package com.mclauncher.java

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mclauncher.java.auth.Accounts
import com.mclauncher.java.auth.MicrosoftAuth
import com.mclauncher.java.builds.Build
import com.mclauncher.java.builds.BuildsRepo
import com.mclauncher.java.core.Config
import com.mclauncher.java.core.Http
import com.mclauncher.java.core.HttpException
import com.mclauncher.java.core.Paths
import com.mclauncher.java.downloader.FabricMeta
import com.mclauncher.java.downloader.Installer
import com.mclauncher.java.downloader.McVersion
import com.mclauncher.java.downloader.VersionManifest
import com.mclauncher.java.launcher.LaunchCommand
import com.mclauncher.java.launcher.Player
import com.mclauncher.java.launcher.Runtimes
import com.mclauncher.java.mods.ModEntry
import com.mclauncher.java.mods.ModKind
import com.mclauncher.java.mods.ModsRepo
import com.mclauncher.java.news.NewsItem
import com.mclauncher.java.news.NewsRepo
import com.mclauncher.java.settings.LauncherSettings
import com.mclauncher.java.settings.SettingsStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

data class Op(val key: String, val label: String, val fraction: Float)
data class Dlg(val title: String, val text: String, val command: String? = null, val url: String? = null)
data class LoginUi(val code: String, val url: String)

class LauncherVM(private val app: Application) : AndroidViewModel(app) {

    val store = SettingsStore(app)
    val settings: StateFlow<LauncherSettings> =
        store.flow.stateIn(viewModelScope, SharingStarted.Eagerly, LauncherSettings())

    val versions = MutableStateFlow<List<McVersion>>(emptyList())
    val latest = MutableStateFlow("")
    val versionsError = MutableStateFlow<String?>(null)
    val installed = MutableStateFlow<List<String>>(emptyList())
    val builds = MutableStateFlow<List<Build>>(emptyList())
    val modsInstalled = MutableStateFlow<Map<String, String>>(emptyMap())
    val op = MutableStateFlow<Op?>(null)
    val news = MutableStateFlow<List<NewsItem>>(emptyList())
    val newsLoading = MutableStateFlow(false)
    val newsError = MutableStateFlow<String?>(null)
    val skin = MutableStateFlow<ImageBitmap?>(null)
    val cape = MutableStateFlow<ImageBitmap?>(null)
    val login = MutableStateFlow<LoginUi?>(null)
    val dialog = MutableStateFlow<Dlg?>(null)
    val messages = Channel<String>(Channel.BUFFERED)
    private var loginJob: Job? = null

    val hasRuntime: Boolean get() = Runtimes.available(app) != null

    val deviceRamGb: Float = run {
        val am = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        mi.totalMem / 1073741824f
    }

    init {
        refreshVersions()
        settings.map { it.gameDir to it.selectedBuild }
            .distinctUntilChanged()
            .onEach { refreshLocal() }
            .launchIn(viewModelScope)
    }

    // ---------- вспомогательное ----------

    fun toast(m: String) {
        messages.trySend(m)
    }

    fun gameDir(): File = Paths.gameDir(app, settings.value.gameDir)

    fun workDir(): File {
        val b = settings.value.selectedBuild
        return if (b.isEmpty()) gameDir() else BuildsRepo(gameDir()).dir(b)
    }

    fun openUrl(url: String) {
        try {
            app.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast("Не удалось открыть ссылку")
        }
    }

    /** Ванильная версия, на которой основан профиль (для Fabric — поле inheritsFrom). */
    fun baseMc(id: String): String? {
        if (id.isEmpty()) return null
        val f = File(gameDir(), "versions/$id/$id.json")
        if (!f.exists()) return id
        return runCatching { JSONObject(f.readText()).optString("inheritsFrom").ifEmpty { id } }.getOrDefault(id)
    }

    fun refreshVersions() {
        versionsError.value = null
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val (list, lat) = VersionManifest.fetch(File(app.cacheDir, "manifest.json"))
                versions.value = list
                latest.value = lat
            } catch (e: Exception) {
                versionsError.value = "Не удалось загрузить список версий. Проверьте интернет."
            }
        }
    }

    fun refreshLocal() {
        viewModelScope.launch(Dispatchers.IO) {
            val g = gameDir()
            installed.value = Installer(g).installedIds()
            builds.value = BuildsRepo(g).list()
            modsInstalled.value = ModsRepo(workDir()).installed()
            loadImages()
        }
    }

    // ---------- настройки ----------

    fun saveSettings(d: LauncherSettings) {
        viewModelScope.launch {
            store.update {
                it.copy(
                    resolution = d.resolution, fps = d.fps, ramGb = d.ramGb,
                    javaRuntime = d.javaRuntime, jvmArgs = d.jvmArgs, language = d.language
                )
            }
            toast("Настройки сохранены")
        }
    }

    fun setGameDir(path: String) {
        val p = path.trim()
        if (p.isNotEmpty()) {
            val f = File(p)
            if (!(f.isDirectory || f.mkdirs()) || !f.canWrite()) {
                toast("Нет доступа к папке: $p")
                return
            }
        }
        viewModelScope.launch {
            store.update { it.copy(gameDir = p, selected = "", selectedBuild = "") }
            toast(if (p.isEmpty()) "Папка игры: по умолчанию" else "Папка игры изменена")
        }
    }

    fun select(id: String, build: String) {
        viewModelScope.launch { store.update { it.copy(selected = id, selectedBuild = build) } }
    }

    fun clearCache() {
        viewModelScope.launch(Dispatchers.IO) {
            app.cacheDir.listFiles()?.forEach { it.deleteRecursively() }
            toast("Кэш очищен")
        }
    }

    // ---------- операции с прогрессом ----------

    private fun runOp(key: String, label: String, block: suspend ((String, Float) -> Unit) -> Unit) {
        if (op.value != null) {
            toast("Дождитесь завершения текущей операции")
            return
        }
        op.value = Op(key, label, 0f)
        viewModelScope.launch {
            try {
                block { l, f -> op.value = Op(key, l, f) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast("Ошибка: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                op.value = null
                refreshLocal()
            }
        }
    }

    fun installVersion(v: McVersion, selectAfter: Boolean) {
        runOp("ver:${v.id}", "Установка ${v.id}") { report ->
            Installer(gameDir()).installVanilla(v, report)
            if (selectAfter) store.update { it.copy(selected = v.id, selectedBuild = "") }
            toast("Версия ${v.id} установлена")
        }
    }

    private suspend fun ensureVanilla(mc: String, report: (String, Float) -> Unit) {
        val inst = Installer(gameDir())
        if (inst.isInstalled(mc)) return
        val v = versions.value.firstOrNull { it.id == mc }
            ?: error("Версия $mc не найдена в манифесте (нужен интернет)")
        inst.installVanilla(v, report)
    }

    private suspend fun installFabricFor(mc: String, report: (String, Float) -> Unit): String {
        ensureVanilla(mc, report)
        val (id, json) = withContext(Dispatchers.IO) {
            FabricMeta.profile(mc, FabricMeta.latestLoader(mc))
        }
        Installer(gameDir()).installProfile(id, json, report)
        return id
    }

    fun installFabric() {
        val base = baseMc(settings.value.selected)
        if (base == null) {
            toast("Сначала выберите версию Minecraft")
            return
        }
        runOp("mod:fabric", "Установка Fabric") { report ->
            val id = installFabricFor(base, report)
            store.update { it.copy(selected = id, selectedBuild = "") }
            toast("Fabric установлен и выбран: $id")
        }
    }

    // ---------- моды ----------

    fun installMod(e: ModEntry) {
        when (e.kind) {
            ModKind.FABRIC -> installFabric()
            ModKind.WEBSITE -> openUrl(e.url)
            ModKind.MODRINTH -> {
                val s = settings.value
                val base = baseMc(s.selected)
                if (base == null) {
                    toast("Сначала выберите версию Minecraft")
                    return
                }
                val target = workDir()
                runOp("mod:${e.id}", "Установка ${e.name}") { report ->
                    report("Поиск файла на Modrinth…", 0.3f)
                    withContext(Dispatchers.IO) { ModsRepo(target).installModrinth(e.id, e.slug, base, "fabric") }
                    val hint = if (s.selected.startsWith("fabric-loader")) "" else " Для работы нужен профиль Fabric."
                    toast("${e.name} установлен.$hint")
                }
            }
        }
    }

    fun removeMod(key: String) {
        viewModelScope.launch(Dispatchers.IO) {
            ModsRepo(workDir()).remove(key)
            refreshLocal()
        }
    }

    // ---------- сборки ----------

    private suspend fun doBuild(b: Build, report: (String, Float) -> Unit) {
        val g = gameDir()
        ensureVanilla(b.mc, report)
        val vid = if (b.loader == "fabric") installFabricFor(b.mc, report) else b.mc
        val repo = BuildsRepo(g)
        repo.save(b.copy(versionId = vid))
        val mr = ModsRepo(repo.dir(b.id))
        b.mods.forEachIndexed { i, slug ->
            report("Мод $slug", i / b.mods.size.toFloat())
            withContext(Dispatchers.IO) { mr.installModrinth(slug, slug, b.mc, "fabric") }
        }
    }

    fun installBuild(b: Build) {
        runOp("build:${b.id}", "Сборка ${b.name}") { report ->
            doBuild(b, report)
            toast(
                if (b.loader == "forge") "Профиль «${b.name}» создан. Forge и моды нужно добавить вручную."
                else "Сборка «${b.name}» установлена"
            )
        }
    }

    fun createBuild(name: String, mc: String, loader: String) {
        val id = "custom-" + name.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-') + "-" + System.currentTimeMillis() % 100000
        installBuild(Build(id, name, "Своя сборка", mc, loader.lowercase(), emptyList(), custom = true))
    }

    fun removeBuild(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            BuildsRepo(gameDir()).remove(id)
            if (settings.value.selectedBuild == id) store.update { it.copy(selected = "", selectedBuild = "") }
            refreshLocal()
            toast("Сборка удалена")
        }
    }

    fun buildMods(id: String): List<String> =
        File(BuildsRepo(gameDir()).dir(id), "mods").listFiles()
            ?.filter { it.isFile && it.name.endsWith(".jar") }?.map { it.name }?.sorted() ?: emptyList()

    fun deleteBuildMod(buildId: String, file: String) {
        File(File(BuildsRepo(gameDir()).dir(buildId), "mods"), file).delete()
    }

    fun addJarToBuild(buildId: String, uri: Uri, done: () -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val name = app.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
                } ?: "mod-${System.currentTimeMillis()}.jar"
                if (!name.endsWith(".jar")) error("Нужен файл .jar")
                val dir = File(BuildsRepo(gameDir()).dir(buildId), "mods").also { it.mkdirs() }
                val input = app.contentResolver.openInputStream(uri) ?: error("Не удалось прочитать файл")
                input.use { i -> File(dir, name).outputStream().use { o -> i.copyTo(o) } }
                toast("Добавлено: $name")
            } catch (e: Exception) {
                toast("Ошибка: ${e.message}")
            }
            withContext(Dispatchers.Main) { done() }
        }
    }

    // ---------- запуск ----------

    private suspend fun currentPlayer(s: LauncherSettings): Player {
        if (s.accountType != "microsoft") return Accounts.offline(s)
        if (s.msToken.isNotEmpty() && System.currentTimeMillis() < s.msExpiry) {
            return Player(s.msName, s.msUuid, s.msToken, "msa")
        }
        if (BuildConfig.MS_CLIENT_ID.isBlank() || s.msRefresh.isBlank()) {
            error("Сессия Microsoft истекла. Войдите заново на экране «Аккаунт».")
        }
        val ses = MicrosoftAuth.refresh(BuildConfig.MS_CLIENT_ID, s.msRefresh)
        store.update {
            it.copy(msName = ses.name, msUuid = ses.uuid, msToken = ses.token, msRefresh = ses.refresh, msExpiry = ses.expiry)
        }
        return Player(ses.name, ses.uuid, ses.token, "msa")
    }

    fun play() {
        val s = settings.value
        viewModelScope.launch {
            val g = gameDir()
            val id = s.selected
            if (id.isEmpty() || !Installer(g).isInstalled(id)) {
                dialog.value = Dlg("Версия не установлена", "Выберите и установите версию на экране «Выбор версии».")
                return@launch
            }
            val player = try {
                currentPlayer(s)
            } catch (e: Exception) {
                dialog.value = Dlg("Вход не выполнен", e.message ?: "Ошибка авторизации")
                return@launch
            }
            val plan = try {
                withContext(Dispatchers.IO) { LaunchCommand.build(g, workDir(), id, player, s) }
            } catch (e: Exception) {
                dialog.value = Dlg("Не удалось подготовить запуск", e.message ?: e.toString())
                return@launch
            }
            val backend = Runtimes.available(app)
            if (backend == null) {
                dialog.value = Dlg(
                    "Java-рантайм не подключён",
                    "Файлы версии $id проверены, команда запуска сформирована. Но в этой сборке нет Java-рантайма " +
                        "с графическим мостом OpenGL, поэтому игра не может стартовать. Подключение — в " +
                        "docs/RUNTIME_INTEGRATION.md.\n\nСформированная команда:",
                    command = plan.commandLine()
                )
                return@launch
            }
            try {
                backend.launch(app, plan, s.javaRuntime)
            } catch (e: Exception) {
                dialog.value = Dlg("Ошибка запуска", e.message ?: e.toString())
            }
        }
    }

    // ---------- аккаунт ----------

    fun setName(n: String): Boolean {
        if (!Accounts.validName(n)) {
            toast("Ник: 3–16 символов, латиница, цифры и _")
            return false
        }
        viewModelScope.launch { store.update { it.copy(playerName = n, accountType = "offline") } }
        return true
    }

    fun startMicrosoft() {
        val cid = BuildConfig.MS_CLIENT_ID
        if (cid.isBlank()) {
            dialog.value = Dlg(
                "Нужен Azure Client ID",
                "Вход через Microsoft идёт по официальному OAuth (device code), пароли не вводятся и не хранятся. " +
                    "Для него нужен Client ID вашего приложения Azure. Укажите его при сборке " +
                    "(-PMS_CLIENT_ID=… или секрет MS_CLIENT_ID в GitHub). Подробности — в README."
            )
            return
        }
        loginJob?.cancel()
        loginJob = viewModelScope.launch {
            try {
                val dc = withContext(Dispatchers.IO) { MicrosoftAuth.start(cid) }
                login.value = LoginUi(dc.userCode, dc.url)
                val ses = MicrosoftAuth.poll(cid, dc)
                store.update {
                    it.copy(
                        accountType = "microsoft", msName = ses.name, msUuid = ses.uuid,
                        msToken = ses.token, msRefresh = ses.refresh, msExpiry = ses.expiry
                    )
                }
                toast("Вы вошли как ${ses.name}")
            } catch (e: CancellationException) {
                throw e
            } catch (e: HttpException) {
                toast(if (e.code == 404) "На этом аккаунте нет Minecraft: Java Edition" else "Ошибка входа: HTTP ${e.code}")
            } catch (e: Exception) {
                toast(e.message ?: "Ошибка входа")
            } finally {
                login.value = null
            }
        }
    }

    fun cancelLogin() {
        loginJob?.cancel()
        login.value = null
    }

    fun logoutMicrosoft() {
        viewModelScope.launch {
            store.update { it.copy(accountType = "offline", msName = "", msUuid = "", msToken = "", msRefresh = "", msExpiry = 0L) }
        }
    }

    private fun decode(f: File): ImageBitmap? =
        if (f.exists()) BitmapFactory.decodeFile(f.path)?.asImageBitmap() else null

    private fun loadImages() {
        skin.value = decode(File(app.filesDir, "skin.png"))
        cape.value = decode(File(app.filesDir, "cape.png"))
    }

    fun setImage(uri: Uri, isCape: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val input = app.contentResolver.openInputStream(uri) ?: error("Не удалось прочитать файл")
                val bytes = input.use { it.readBytes() }
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: error("Это не изображение PNG")
                val ok = if (isCape) (bmp.width == 64 && bmp.height == 32) || (bmp.width == 22 && bmp.height == 17)
                else bmp.width == 64 && (bmp.height == 64 || bmp.height == 32)
                if (!ok) error("Неверный размер ${bmp.width}×${bmp.height}")
                File(app.filesDir, if (isCape) "cape.png" else "skin.png").writeBytes(bytes)
                loadImages()
                toast(if (isCape) "Плащ выбран" else "Скин выбран")
            } catch (e: Exception) {
                toast("Ошибка: ${e.message}")
            }
        }
    }

    fun resetImage(isCape: Boolean) {
        File(app.filesDir, if (isCape) "cape.png" else "skin.png").delete()
        loadImages()
    }

    // ---------- новости и обновления ----------

    fun loadNews() {
        if (newsLoading.value) return
        newsLoading.value = true
        newsError.value = null
        viewModelScope.launch(Dispatchers.IO) {
            try {
                news.value = NewsRepo.fetch(File(app.cacheDir, "news.json"))
            } catch (e: Exception) {
                newsError.value = "Не удалось загрузить новости. Проверьте интернет."
            }
            newsLoading.value = false
        }
    }

    fun checkUpdates() {
        viewModelScope.launch(Dispatchers.IO) {
            if (Config.repo.startsWith("OWNER/")) {
                dialog.value = Dlg(
                    "Обновления",
                    "Репозиторий GitHub не настроен. При сборке в GitHub Actions он подставляется автоматически " +
                        "(-PGITHUB_REPO=владелец/репозиторий)."
                )
                return@launch
            }
            try {
                val j = JSONObject(
                    Http.text(
                        "https://api.github.com/repos/${Config.repo}/releases/latest",
                        headers = mapOf("Accept" to "application/vnd.github+json")
                    )
                )
                val tag = j.getString("tag_name").removePrefix("v")
                dialog.value = if (tag != BuildConfig.VERSION_NAME)
                    Dlg("Доступно обновление $tag", "Установлена версия ${BuildConfig.VERSION_NAME}.", url = j.getString("html_url"))
                else Dlg("Обновлений нет", "У вас последняя версия ${BuildConfig.VERSION_NAME}.")
            } catch (e: Exception) {
                dialog.value = Dlg("Не удалось проверить", "Релизов ещё нет или нет интернета.")
            }
        }
    }
}
