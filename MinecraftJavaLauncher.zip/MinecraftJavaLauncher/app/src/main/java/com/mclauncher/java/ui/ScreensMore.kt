package com.mclauncher.java.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mclauncher.java.BuildConfig
import com.mclauncher.java.Dlg
import com.mclauncher.java.LauncherVM
import com.mclauncher.java.auth.Accounts
import com.mclauncher.java.builds.Build
import com.mclauncher.java.builds.BuildCatalog
import com.mclauncher.java.core.Config
import com.mclauncher.java.mods.ModCatalog
import com.mclauncher.java.mods.ModEntry
import com.mclauncher.java.mods.ModKind
import com.mclauncher.java.news.NewsRepo

@Composable
private fun WideBtn(glyph: String, text: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(16.dp).card().clickable(onClick = onClick).padding(16.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        Text(glyph, fontSize = 20.sp)
        Spacer(Modifier.width(10.dp))
        Text(text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

// ======================= МОДЫ =======================

@Composable
fun ModsScreen(vm: LauncherVM, back: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val installed by vm.installed.collectAsStateWithLifecycle()
    val mods by vm.modsInstalled.collectAsStateWithLifecycle()
    val builds by vm.builds.collectAsStateWithLifecycle()
    val op by vm.op.collectAsStateWithLifecycle()
    var tab by remember { mutableIntStateOf(0) }
    val base = remember(s.selected, installed) { vm.baseMc(s.selected) }
    val target = builds.firstOrNull { it.id == s.selectedBuild }?.name ?: "основная папка"

    Column(Modifier.fillMaxSize()) {
        TopBar("Моды", back)
        Tabs(listOf("Каталог", "Установленные"), tab) { tab = it }
        Text(
            "Minecraft: ${base ?: "не выбрана"} · куда: $target", color = Mc.Dim, fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        LazyColumn(
            Modifier.weight(1f).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (tab == 0) {
                items(ModCatalog.all, key = { it.id }) { e ->
                    val status = when (e.kind) {
                        ModKind.FABRIC ->
                            if (base != null && installed.any { it.startsWith("fabric-loader-") && it.endsWith("-$base") })
                                "Установлено" else "Установить"
                        ModKind.MODRINTH -> if (mods.containsKey(e.id)) "Установлено" else "Установить"
                        ModKind.WEBSITE -> "Сайт"
                    }
                    ModRow(e, status, busy = op?.key == "mod:${e.id}", enabled = op == null) { vm.installMod(e) }
                }
            } else {
                if (mods.isEmpty()) {
                    item { Text("Установленных модов нет", color = Mc.Dim, modifier = Modifier.padding(16.dp)) }
                }
                items(mods.entries.toList(), key = { it.key }) { m ->
                    val name = ModCatalog.all.firstOrNull { it.id == m.key }?.name ?: m.value
                    Row(Modifier.fillMaxWidth().card().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text(m.value, color = Mc.Dim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        OutlineBtn("Удалить", { vm.removeMod(m.key) })
                    }
                }
            }
        }
        WideBtn("🧩", "Управление модами") { tab = 1 }
    }
}

@Composable
private fun ModRow(e: ModEntry, status: String, busy: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().card().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF232823)),
            contentAlignment = Alignment.Center
        ) { Text(e.glyph, fontSize = 26.sp) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(e.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(e.desc, color = Mc.Dim, fontSize = 12.sp)
        }
        Spacer(Modifier.width(8.dp))
        when {
            busy -> Text("…", color = Mc.Green, fontSize = 20.sp)
            status == "Установлено" -> Text("✓ Установлено", color = Mc.Green, fontSize = 13.sp)
            else -> OutlineBtn(status, onClick, enabled = enabled)
        }
    }
}

// ======================= СБОРКИ =======================

@Composable
fun BuildsScreen(vm: LauncherVM, back: () -> Unit) {
    val builds by vm.builds.collectAsStateWithLifecycle()
    val op by vm.op.collectAsStateWithLifecycle()
    var create by remember { mutableStateOf(false) }
    var modsFor by remember { mutableStateOf<Build?>(null) }
    val list = BuildCatalog.all + builds.filter { it.custom }

    Column(Modifier.fillMaxSize()) {
        TopBar("Сборки", back)
        LazyColumn(
            Modifier.weight(1f).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(list, key = { it.id }) { b ->
                val inst = builds.firstOrNull { it.id == b.id }
                val busy = op?.key == "build:${b.id}"
                val modCount = remember(builds, op) { if (inst != null) vm.buildMods(b.id).size else 0 }
                val glyph = when (b.id) {
                    "vanilla-plus" -> "🌳"
                    "technomagic" -> "⚙️"
                    "skyblock" -> "🏝️"
                    "rlcraft" -> "💀"
                    else -> "🧱"
                }
                Row(Modifier.fillMaxWidth().card().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF232823)),
                        contentAlignment = Alignment.Center
                    ) { Text(glyph, fontSize = 28.sp) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(b.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text(b.desc, color = Mc.Dim, fontSize = 12.sp)
                        val info = if (inst != null)
                            "Установлена · ${b.mc} · моды: $modCount" + if (b.loader == "forge") " · Forge вручную" else ""
                        else "${b.mc} · ${b.loader}"
                        Text(info, color = if (inst != null) Mc.Green else Mc.Dim, fontSize = 11.sp)
                    }
                    Spacer(Modifier.width(8.dp))
                    when {
                        busy -> Text("…", color = Mc.Green, fontSize = 20.sp)
                        inst == null -> OutlineBtn("Установить", { vm.installBuild(b) }, enabled = op == null)
                        else -> Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            OutlineBtn("Моды", { modsFor = inst })
                            OutlineBtn("Удалить", { vm.removeBuild(b.id) })
                        }
                    }
                }
            }
        }
        op?.let {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Text(it.label, color = Mc.Dim, fontSize = 12.sp)
                LoadingBar(it.fraction, Modifier.fillMaxWidth().padding(top = 4.dp))
            }
        }
        WideBtn("🧊", "Создать свою сборку") { create = true }
    }
    if (create) CreateBuildDialog(vm) { create = false }
    modsFor?.let { b -> BuildModsDialog(vm, b) { modsFor = null } }
}

@Composable
private fun CreateBuildDialog(vm: LauncherVM, onDismiss: () -> Unit) {
    val versions by vm.versions.collectAsStateWithLifecycle()
    val releases = remember(versions) { versions.filter { it.type == "release" }.map { it.id } }
    var name by remember { mutableStateOf("") }
    var mc by remember { mutableStateOf("") }
    var loader by remember { mutableStateOf("Vanilla") }
    val ver = mc.ifEmpty { releases.firstOrNull() ?: "" }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Mc.Card,
        title = { Text("Новая сборка", color = Color.White) },
        text = {
            Column {
                McField(name, { name = it }, Modifier.fillMaxWidth(), "Название")
                if (releases.isEmpty()) {
                    Text("Список версий не загружен (нужен интернет).", color = Mc.Warn, fontSize = 12.sp)
                } else {
                    DropRow("Версия", ver, releases) { mc = it }
                }
                DropRow("Загрузчик", loader, listOf("Vanilla", "Fabric")) { loader = it }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank() && ver.isNotEmpty(),
                onClick = { vm.createBuild(name.trim(), ver, loader); onDismiss() }
            ) { Text("Создать", color = Mc.Green) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = Mc.Dim) } }
    )
}

@Composable
private fun BuildModsDialog(vm: LauncherVM, b: Build, onDismiss: () -> Unit) {
    var files by remember { mutableStateOf(vm.buildMods(b.id)) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.addJarToBuild(b.id, uri) { files = vm.buildMods(b.id) }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Mc.Card,
        title = { Text("Моды: ${b.name}", color = Color.White) },
        text = {
            Column(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                if (files.isEmpty()) Text("Модов нет. Добавьте файл .jar.", color = Mc.Dim)
                files.forEach { f ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(f, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        TextButton(onClick = { vm.deleteBuildMod(b.id, f); files = vm.buildMods(b.id) }) {
                            Text("Удалить", color = Mc.Warn)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Row {
                TextButton(onClick = { pick.launch("*/*") }) { Text("Добавить .jar", color = Mc.Green) }
                TextButton(onClick = onDismiss) { Text("Закрыть", color = Mc.Green) }
            }
        }
    )
}

// ======================= АККАУНТ =======================

@Composable
private fun MsLogo() {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            Box(Modifier.size(10.dp).background(Color(0xFFF25022)))
            Box(Modifier.size(10.dp).background(Color(0xFF7FBA00)))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            Box(Modifier.size(10.dp).background(Color(0xFF00A4EF)))
            Box(Modifier.size(10.dp).background(Color(0xFFFFB900)))
        }
    }
}

@Composable
fun AccountScreen(vm: LauncherVM, back: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val skin by vm.skin.collectAsStateWithLifecycle()
    val cape by vm.cape.collectAsStateWithLifecycle()
    val login by vm.login.collectAsStateWithLifecycle()
    var editName by remember { mutableStateOf(false) }
    var nameText by remember { mutableStateOf("") }
    val skinPick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.setImage(uri, false)
    }
    val capePick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.setImage(uri, true)
    }
    val ms = s.accountType == "microsoft"
    val name = if (ms) s.msName else s.playerName
    val uuid = if (ms) s.msUuid else Accounts.offlineUuid(s.playerName)

    Column(Modifier.fillMaxSize()) {
        TopBar("Аккаунт", back)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                Modifier.fillMaxWidth().card()
                    .clickable(enabled = !ms) { nameText = s.playerName; editName = true }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SkinHead(skin, Modifier.size(56.dp).clip(RoundedCornerShape(6.dp)))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(if (ms) "Аккаунт Microsoft" else "Оффлайн-аккаунт", color = Mc.Dim, fontSize = 14.sp)
                    Text(uuid, color = Mc.Dim, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (!ms) Text("✎", color = Mc.Dim, fontSize = 18.sp)
            }
            Row(
                Modifier.fillMaxWidth().card()
                    .clickable { if (ms) vm.logoutMicrosoft() else vm.startMicrosoft() }.padding(16.dp),
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
            ) {
                MsLogo()
                Spacer(Modifier.width(12.dp))
                Text(
                    if (ms) "Выйти из Microsoft" else "Войти с Microsoft",
                    color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium
                )
            }
            Section("Скин", "🎨") {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    SkinPreview(skin, Modifier.size(64.dp, 128.dp))
                    Spacer(Modifier.width(16.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlineBtn("Выбрать скин", { skinPick.launch("image/png") })
                        OutlineBtn("Сбросить", { vm.resetImage(false) }, enabled = skin != null)
                    }
                }
            }
            Section("Плащ", "🧣") {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    CapePreview(cape, Modifier.size(64.dp, 100.dp).clip(RoundedCornerShape(6.dp)))
                    Spacer(Modifier.width(16.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlineBtn("Выбрать плащ", { capePick.launch("image/png") })
                        OutlineBtn("Сбросить", { vm.resetImage(true) }, enabled = cape != null)
                    }
                }
            }
            Row(Modifier.fillMaxWidth().card().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("ℹ️", fontSize = 22.sp)
                Spacer(Modifier.width(12.dp))
                Text(
                    "Для входа с аккаунтом Microsoft нужен интернет. Скин и плащ сохраняются локально " +
                        "(предпросмотр); в игре офлайн-аккаунт их не показывает.",
                    color = Color.White, fontSize = 13.sp
                )
            }
            Spacer(Modifier.height(8.dp))
        }
    }

    login?.let { l ->
        AlertDialog(
            onDismissRequest = { vm.cancelLogin() },
            containerColor = Mc.Card,
            title = { Text("Вход через Microsoft", color = Color.White) },
            text = {
                Column {
                    Text("Откройте страницу Microsoft и введите код:", color = Mc.Dim)
                    Spacer(Modifier.height(8.dp))
                    Text(l.code, color = Mc.Green, fontSize = 30.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Text(l.url, color = Mc.Dim, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Окно закроется само после входа.", color = Mc.Dim, fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = { vm.openUrl(l.url) }) { Text("Открыть сайт", color = Mc.Green) } },
            dismissButton = { TextButton(onClick = { vm.cancelLogin() }) { Text("Отмена", color = Mc.Dim) } }
        )
    }
    if (editName) {
        AlertDialog(
            onDismissRequest = { editName = false },
            containerColor = Mc.Card,
            title = { Text("Имя игрока", color = Color.White) },
            text = { McField(nameText, { nameText = it }, Modifier.fillMaxWidth(), "Ник (3–16 символов)") },
            confirmButton = {
                TextButton(onClick = { if (vm.setName(nameText.trim())) editName = false }) {
                    Text("Сохранить", color = Mc.Green)
                }
            },
            dismissButton = { TextButton(onClick = { editName = false }) { Text("Отмена", color = Mc.Dim) } }
        )
    }
}

// ======================= НОВОСТИ =======================

@Composable
fun NewsScreen(vm: LauncherVM, back: () -> Unit) {
    val news by vm.news.collectAsStateWithLifecycle()
    val loading by vm.newsLoading.collectAsStateWithLifecycle()
    val err by vm.newsError.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { if (news.isEmpty()) vm.loadNews() }

    Column(Modifier.fillMaxSize()) {
        TopBar("Новости", back)
        if (news.isNotEmpty()) {
            LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(news) { n ->
                    Column(Modifier.fillMaxWidth().card()) {
                        if (n.image.isNotEmpty()) RemoteImage(n.image, Modifier.fillMaxWidth().height(150.dp))
                        Column(Modifier.padding(14.dp)) {
                            Text(n.title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text(NewsRepo.prettyDate(n.date), color = Mc.Dim, fontSize = 13.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("Читать далее →", color = Mc.Green, fontSize = 14.sp, modifier = Modifier.clickable { vm.openUrl(n.url) })
                        }
                    }
                }
            }
        } else {
            Column(Modifier.weight(1f).fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (loading) {
                    Text("Загрузка новостей…", color = Mc.Dim)
                    Spacer(Modifier.height(12.dp))
                    LoadingBar(0.5f, Modifier.width(140.dp))
                } else {
                    Text(err ?: "Новостей пока нет", color = Mc.Dim)
                    Spacer(Modifier.height(12.dp))
                    OutlineBtn("Повторить", { vm.loadNews() })
                }
            }
        }
    }
}

// ======================= ЕЩЁ =======================

@Composable
private fun MoreRow(glyph: String, title: String, sub: String?, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(glyph, fontSize = 22.sp)
        Spacer(Modifier.width(16.dp))
        Column {
            Text(title, color = Color.White, fontSize = 16.sp)
            if (sub != null) Text(sub, color = Mc.Dim, fontSize = 12.sp)
        }
    }
}

@Composable
fun MoreScreen(vm: LauncherVM, back: () -> Unit, onExit: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    var folder by remember { mutableStateOf(false) }
    var folderText by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize()) {
        TopBar("Ещё", back)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Column(Modifier.padding(horizontal = 16.dp).card()) {
                MoreRow("ℹ️", "О лаунчере", "Версия: ${BuildConfig.VERSION_NAME}") {
                    vm.dialog.value = Dlg(
                        "Minecraft Java Launcher ${BuildConfig.VERSION_NAME}",
                        "Неофициальный проект. Minecraft — товарный знак Mojang Studios / Microsoft.\n\n" +
                            "Данные: Mojang (версии, ассеты, новости), FabricMC Meta, Modrinth.\n" +
                            "Код лаунчера — MIT. Java-рантайм (Pojav-совместимый, LGPL-3.0) в эту сборку не включён."
                    )
                }
                MoreRow("🔄", "Проверить обновления", null) { vm.checkUpdates() }
                MoreRow("🗑️", "Очистить кэш", null) { vm.clearCache() }
                MoreRow("📁", "Папка с игрой", null) { folderText = s.gameDir.ifEmpty { vm.gameDir().path }; folder = true }
                MoreRow("❓", "Поддержка", null) { vm.openUrl(Config.supportUrl) }
                MoreRow("💬", "Discord", null) { vm.openUrl(Config.DISCORD_URL) }
                MoreRow("🚪", "Выход", null) { onExit() }
            }
            Spacer(Modifier.height(20.dp))
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                CreeperFace(Modifier.size(160.dp).clip(RoundedCornerShape(16.dp)))
            }
            Spacer(Modifier.height(20.dp))
        }
    }

    if (folder) {
        AlertDialog(
            onDismissRequest = { folder = false },
            containerColor = Mc.Card,
            title = { Text("Папка с игрой", color = Color.White) },
            text = {
                Column {
                    Text("Здесь хранятся версии, библиотеки, ассеты, моды и сборки.", color = Mc.Dim, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    McField(folderText, { folderText = it }, Modifier.fillMaxWidth(), "Путь")
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.setGameDir(folderText); folder = false }) { Text("Сохранить", color = Mc.Green) }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { vm.setGameDir(""); folder = false }) { Text("По умолчанию", color = Mc.Dim) }
                    TextButton(onClick = { folder = false }) { Text("Закрыть", color = Mc.Dim) }
                }
            }
        )
    }
}
