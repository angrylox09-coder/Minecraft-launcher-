package com.mclauncher.java.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mclauncher.java.LauncherVM
import com.mclauncher.java.settings.LauncherSettings
import kotlin.math.floor
import kotlin.math.roundToInt

// ======================= ГЛАВНЫЙ ЭКРАН =======================

@Composable
fun HomeScreen(vm: LauncherVM, go: (Screen) -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val installed by vm.installed.collectAsStateWithLifecycle()
    val builds by vm.builds.collectAsStateWithLifecycle()
    val op by vm.op.collectAsStateWithLifecycle()

    val isInstalled = s.selected in installed
    val runtimeOk = remember { vm.hasRuntime }
    val o = op
    val (statusText, statusColor) = when {
        o != null -> "${o.label}… ${(o.fraction * 100).toInt()}%" to Mc.Warn
        s.selected.isEmpty() -> "Выберите версию" to Mc.Warn
        !isInstalled -> "Версия не установлена" to Mc.Warn
        !runtimeOk -> "Файлы готовы · нет Java-рантайма" to Mc.Warn
        else -> "Готов к запуску!" to Mc.Green
    }
    val buildName = builds.firstOrNull { it.id == s.selectedBuild }?.name
    val loaderName = if (s.selected.startsWith("fabric-loader")) "Fabric" else "Vanilla"

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CreeperFace(Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Minecraft", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Java Launcher", color = Mc.Dim, fontSize = 15.sp)
            }
            IconButton(onClick = { go(Screen.Settings) }) {
                Icon(Icons.Default.Settings, contentDescription = "Настройки", tint = Mc.Dim)
            }
        }
        Spacer(Modifier.height(12.dp))
        Banner(Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(16.dp)))
        Spacer(Modifier.height(12.dp))
        McButton(
            "ИГРАТЬ", onClick = { vm.play() }, modifier = Modifier.fillMaxWidth(), big = true,
            leading = { Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
        )
        Spacer(Modifier.height(12.dp))
        Row(
            Modifier.fillMaxWidth().card().clickable { go(Screen.Versions) }.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Grass(48.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Версия:", color = Mc.Dim, fontSize = 13.sp)
                Text(s.selected.ifEmpty { "Не выбрана" }, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Сборка: ${buildName ?: "официальная"} · $loaderName", color = Mc.Dim, fontSize = 12.sp)
            }
            Text("▾", color = Mc.Dim, fontSize = 20.sp)
        }
        Spacer(Modifier.height(12.dp))
        TileRow(listOf(Triple("🧩", "Моды", Screen.Mods), Triple("📦", "Сборки", Screen.Builds), Triple("⚙️", "Настройки", Screen.Settings)), go)
        Spacer(Modifier.height(8.dp))
        TileRow(listOf(Triple("📰", "Новости", Screen.News), Triple("👤", "Аккаунт", Screen.Account), Triple("⋯", "Ещё", Screen.More)), go)
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(statusColor))
            Spacer(Modifier.width(8.dp))
            Text(statusText, color = statusColor, fontSize = 13.sp)
        }
    }
}

@Composable
private fun TileRow(items: List<Triple<String, String, Screen>>, go: (Screen) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { (glyph, label, target) ->
            Column(
                Modifier.weight(1f).card().clickable { go(target) }.padding(vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(glyph, fontSize = 26.sp)
                Spacer(Modifier.height(4.dp))
                Text(label, color = Color.White, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun Banner(modifier: Modifier) {
    Box(modifier) {
        Canvas(Modifier.matchParentSize()) {
            drawRect(Brush.verticalGradient(listOf(Color(0xFF2B2158), Color(0xFFB4506A), Color(0xFFF08A3C), Color(0xFFF7C873))))
            drawCircle(Color(0xFFFFEBB0), size.width * 0.07f, Offset(size.width * 0.36f, size.height * 0.5f))
            val u = size.width / 20f
            val ground = size.height * 0.66f
            for (i in 0 until 20) {
                val h = u * (1 + (i * 7 % 4))
                drawRect(Color(0xFF1B4D1A), Offset(i * u, ground - h), Size(u + 0.5f, h + 2f))
            }
            drawRect(
                Brush.verticalGradient(listOf(Color(0xFF2E7A2A), Color(0xFF0F2A0E)), startY = ground, endY = size.height),
                Offset(0f, ground), Size(size.width, size.height - ground)
            )
            for (tx in listOf(0.1f, 0.22f, 0.8f, 0.92f)) {
                val x = size.width * tx
                drawRect(Color(0xFF4A2E17), Offset(x - u * 0.25f, ground - u * 3), Size(u * 0.5f, u * 3))
                drawRect(Color(0xFF2E7A2A), Offset(x - u * 1.2f, ground - u * 5.2f), Size(u * 2.4f, u * 2.4f))
            }
        }
        Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "MINECRAFT", color = Color(0xFFD6D6D6), fontSize = 38.sp, fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                style = TextStyle(shadow = Shadow(Color.Black, Offset(4f, 4f), 6f))
            )
            Text(
                "JAVA EDITION", color = Color(0xFFF0F0F0), fontSize = 15.sp, fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                style = TextStyle(shadow = Shadow(Color.Black, Offset(2f, 2f), 4f))
            )
        }
    }
}

// ======================= ВЫБОР ВЕРСИИ =======================

@Composable
fun VersionsScreen(vm: LauncherVM, back: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val versions by vm.versions.collectAsStateWithLifecycle()
    val latest by vm.latest.collectAsStateWithLifecycle()
    val installed by vm.installed.collectAsStateWithLifecycle()
    val builds by vm.builds.collectAsStateWithLifecycle()
    val op by vm.op.collectAsStateWithLifecycle()
    val loadErr by vm.versionsError.collectAsStateWithLifecycle()

    var tab by remember { mutableIntStateOf(0) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("Релизы") }
    var pick by remember { mutableStateOf(s.selected) }
    var pickBuild by remember { mutableStateOf(s.selectedBuild) }

    val list = remember(versions, filter, query) {
        versions.filter { v ->
            val typeOk = when (filter) {
                "Релизы" -> v.type == "release"
                "Снапшоты" -> v.type == "snapshot"
                "Старые" -> v.type.startsWith("old_")
                else -> true
            }
            typeOk && (query.isBlank() || v.id.contains(query.trim(), ignoreCase = true))
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar("Выбор версии", back) {
            IconButton(onClick = { searching = !searching; if (!searching) query = "" }) {
                Icon(Icons.Default.Search, contentDescription = "Поиск", tint = Color.White)
            }
        }
        Tabs(listOf("Официальные", "Сборки"), tab) { tab = it }
        if (searching) {
            McField(query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), "Поиск версии")
        }

        if (tab == 0) {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Релизы", "Снапшоты", "Старые", "Все").forEach { f -> Chip(f, filter == f) { filter = f } }
            }
            if (versions.isEmpty()) {
                Column(Modifier.weight(1f).fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(loadErr ?: "Загрузка списка версий…", color = Mc.Dim)
                    if (loadErr != null) {
                        Spacer(Modifier.height(12.dp))
                        OutlineBtn("Повторить", { vm.refreshVersions() })
                    } else {
                        Spacer(Modifier.height(12.dp))
                        LoadingBar(0.5f, Modifier.width(140.dp))
                    }
                }
            } else {
                LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp, vertical = 8.dp).card()) {
                    items(list, key = { it.id }) { v ->
                        val sub = when {
                            v.id == latest -> "Последняя версия" to Mc.Green
                            v.id in installed -> "Установлена" to Mc.Dim
                            else -> null
                        }
                        VersionRow(v.id, sub?.first, sub?.second ?: Mc.Dim, pick == v.id) { pick = v.id; pickBuild = "" }
                    }
                }
            }
        } else {
            LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp, vertical = 8.dp).card()) {
                if (installed.isEmpty() && builds.isEmpty()) {
                    item { Text("Пока ничего не установлено", color = Mc.Dim, modifier = Modifier.padding(20.dp)) }
                }
                items(installed, key = { "v:$it" }) { id ->
                    VersionRow(id, "Установлена", Mc.Dim, pick == id && pickBuild.isEmpty()) { pick = id; pickBuild = "" }
                }
                items(builds, key = { "b:${it.id}" }) { b ->
                    VersionRow(b.name, "Сборка · ${b.mc} · ${b.loader}", Mc.Green, pickBuild == b.id) {
                        pick = b.versionId.ifEmpty { b.mc }; pickBuild = b.id
                    }
                }
            }
        }

        Column(Modifier.padding(16.dp)) {
            val o = op
            if (o != null) {
                Text(o.label, color = Mc.Dim, fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
                LoadingBar(o.fraction, Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
            }
            val isInst = pick in installed
            McButton(
                text = when {
                    o != null -> "Идёт загрузка…"
                    isInst -> "Выбрать"
                    else -> "Установить и выбрать"
                },
                onClick = {
                    if (isInst) {
                        vm.select(pick, pickBuild)
                        back()
                    } else {
                        versions.firstOrNull { it.id == pick }?.let { vm.installVersion(it, true) }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = pick.isNotEmpty() && o == null
            )
        }
    }
}

@Composable
private fun VersionRow(title: String, sub: String?, subColor: Color, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Grass(40.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 18.sp)
            if (sub != null) Text(sub, color = subColor, fontSize = 13.sp)
        }
        RadioButton(
            selected = selected, onClick = null,
            colors = RadioButtonDefaults.colors(selectedColor = Mc.Green, unselectedColor = Mc.Dim)
        )
    }
}

// ======================= НАСТРОЙКИ =======================

private fun withXmx(args: String, gb: Float): String {
    val v = if (gb % 1f == 0f) "-Xmx${gb.toInt()}G" else "-Xmx${(gb * 1024).toInt()}M"
    val re = Regex("-Xmx\\S+")
    return if (re.containsMatchIn(args)) args.replace(re, v) else "$v $args".trim()
}

private fun ramLabel(gb: Float) = if (gb % 1f == 0f) "${gb.toInt()} ГБ" else "$gb ГБ"

@Composable
fun SettingsScreen(vm: LauncherVM, back: () -> Unit) {
    var d by remember { mutableStateOf<LauncherSettings>(vm.settings.value) }
    val maxRam = remember { (floor(vm.deviceRamGb * 0.6f * 2f) / 2f).coerceIn(1.5f, 8f) }
    val steps = (((maxRam - 1f) / 0.5f).toInt() - 1).coerceAtLeast(0)

    Column(Modifier.fillMaxSize()) {
        TopBar("Настройки", back)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Section("Графика", "🖥️") {
                DropRow("Разрешение", d.resolution, listOf("854×480", "1280×720", "1920×1080", "2400×1080")) {
                    d = d.copy(resolution = it)
                }
                DropRow("Лимит FPS", d.fps, listOf("Без ограничений", "30", "60", "90", "120")) { d = d.copy(fps = it) }
                Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                    Row {
                        Text("Выделение RAM", color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                        Text(ramLabel(d.ramGb), color = Mc.Dim, fontSize = 15.sp)
                    }
                    Slider(
                        value = d.ramGb.coerceIn(1f, maxRam),
                        onValueChange = { v ->
                            val r = (v * 2f).roundToInt() / 2f
                            d = d.copy(ramGb = r, jvmArgs = withXmx(d.jvmArgs, r))
                        },
                        valueRange = 1f..maxRam,
                        steps = steps,
                        colors = SliderDefaults.colors(
                            thumbColor = Mc.Green, activeTrackColor = Mc.Green, inactiveTrackColor = Mc.Line,
                            activeTickColor = Mc.GreenDark, inactiveTickColor = Mc.Line
                        )
                    )
                    Text("Память устройства: ${"%.1f".format(vm.deviceRamGb)} ГБ", color = Mc.Dim, fontSize = 12.sp)
                }
            }
            Section("Java", "🔧") {
                DropRow("Путь к Java", d.javaRuntime, listOf("Авто", "Java 8", "Java 17", "Java 21")) {
                    d = d.copy(javaRuntime = it)
                }
                Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Аргументы JVM", color = Color.White, fontSize = 16.sp)
                    Spacer(Modifier.width(12.dp))
                    McField(d.jvmArgs, { d = d.copy(jvmArgs = it) }, Modifier.weight(1f))
                }
            }
            Section("Язык", "🌐") {
                DropRow("Язык лаунчера", d.language, listOf("Русский")) { d = d.copy(language = it) }
            }
            Spacer(Modifier.height(4.dp))
        }
        McButton(
            "Сохранить", onClick = { vm.saveSettings(d) },
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            leading = { Icon(Icons.Default.Check, null, tint = Color.White) }
        )
    }
}
