package com.mclauncher.java.downloader

import com.mclauncher.java.core.Config
import com.mclauncher.java.core.Http
import com.mclauncher.java.core.VersionJson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.atomic.AtomicInteger

data class McVersion(val id: String, val type: String, val url: String, val time: String)

object VersionManifest {
    /** Официальный Version Manifest v2 от Mojang; при отсутствии сети — кэш. */
    fun fetch(cache: File): Pair<List<McVersion>, String> {
        val text = try {
            Http.text(Config.VERSION_MANIFEST).also { cache.writeText(it) }
        } catch (e: Exception) {
            if (cache.exists()) cache.readText() else throw e
        }
        val j = JSONObject(text)
        val arr = j.getJSONArray("versions")
        val list = (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            McVersion(o.getString("id"), o.getString("type"), o.getString("url"), o.optString("releaseTime"))
        }
        return list to j.getJSONObject("latest").getString("release")
    }
}

object FabricMeta {
    fun latestLoader(mc: String): String {
        val arr = JSONArray(Http.text("${Config.FABRIC_META}/versions/loader/$mc"))
        for (i in 0 until arr.length()) {
            val l = arr.getJSONObject(i).getJSONObject("loader")
            if (l.optBoolean("stable", true)) return l.getString("version")
        }
        error("Fabric не поддерживает версию $mc")
    }

    /** Возвращает (id профиля, json профиля). */
    fun profile(mc: String, loader: String): Pair<String, String> {
        val json = Http.text("${Config.FABRIC_META}/versions/loader/$mc/$loader/profile/json")
        return JSONObject(json).getString("id") to json
    }
}

private data class Dl(val url: String, val dest: File, val sha1: String, val size: Long)

class Installer(private val gameDir: File) {

    private fun versionDir(id: String) = File(gameDir, "versions/$id")

    /** Версия считается установленной только после успешной загрузки ВСЕХ файлов. */
    fun isInstalled(id: String) = File(versionDir(id), ".installed").exists()

    fun installedIds(): List<String> =
        File(gameDir, "versions").listFiles()
            ?.filter { File(it, ".installed").exists() }
            ?.map { it.name }
            ?.sortedDescending()
            ?: emptyList()

    suspend fun installVanilla(v: McVersion, report: (String, Float) -> Unit) = withContext(Dispatchers.IO) {
        report("Описание версии ${v.id}", 0f)
        val dir = versionDir(v.id).also { it.mkdirs() }
        File(dir, "${v.id}.json").writeText(Http.text(v.url))
        fetchAll(v.id, report)
    }

    /** Профиль загрузчика (Fabric). Родительская ванильная версия должна быть установлена. */
    suspend fun installProfile(id: String, json: String, report: (String, Float) -> Unit) = withContext(Dispatchers.IO) {
        val dir = versionDir(id).also { it.mkdirs() }
        File(dir, "$id.json").writeText(json)
        fetchAll(id, report)
    }

    private suspend fun fetchAll(id: String, report: (String, Float) -> Unit) {
        val merged = VersionJson.load(gameDir, id)
        val jobs = mutableListOf<Dl>()

        val jarId = VersionJson.jarId(merged, id)
        val jar = File(gameDir, "versions/$jarId/$jarId.jar")
        merged.optJSONObject("downloads")?.optJSONObject("client")?.let { c ->
            if (!jar.exists()) jobs += Dl(c.getString("url"), jar, c.optString("sha1"), c.optLong("size"))
        }
        for (l in VersionJson.libraries(merged)) {
            jobs += Dl(l.url, File(gameDir, "libraries/${l.path}"), l.sha1, l.size)
        }
        merged.optJSONObject("assetIndex")?.let { ai ->
            val idx = File(gameDir, "assets/indexes/${ai.getString("id")}.json")
            if (!idx.exists()) Http.download(ai.getString("url"), idx, ai.optString("sha1"))
            val objs = JSONObject(idx.readText()).getJSONObject("objects")
            for (name in objs.keys()) {
                val o = objs.getJSONObject(name)
                val h = o.getString("hash")
                val p = h.substring(0, 2)
                jobs += Dl("${Config.ASSET_BASE}/$p/$h", File(gameDir, "assets/objects/$p/$h"), h, o.optLong("size"))
            }
        }

        val todo = jobs.distinctBy { it.dest.path }
        val total = todo.size.coerceAtLeast(1)
        val done = AtomicInteger(0)
        val gate = Semaphore(8)
        coroutineScope {
            todo.map { d ->
                async {
                    gate.withPermit {
                        val ok = d.dest.exists() && (d.size <= 0L || d.dest.length() == d.size)
                        if (!ok) fetch(d)
                        val n = done.incrementAndGet()
                        if (n % 20 == 0 || n == total) report("Файлы: $n / $total", n / total.toFloat())
                    }
                }
            }.awaitAll()
        }
        File(versionDir(id), ".installed").writeText("ok")
        report("Готово", 1f)
    }

    private fun fetch(d: Dl) {
        var last: Exception? = null
        repeat(3) {
            try {
                Http.download(d.url, d.dest, d.sha1)
                return
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IllegalStateException("Ошибка загрузки ${d.url}")
    }
}
