# Minecraft Java Launcher для Android

Мобильный лаунчер Minecraft: Java Edition. Kotlin · Jetpack Compose · Material 3 · min Android 8.0 (API 26).
Тёмный Minecraft-интерфейс по макету: главный экран, версии, моды, сборки, аккаунт, новости, настройки, «Ещё».

> **Неофициальный проект.** Minecraft — товарный знак Mojang Studios / Microsoft. Игру нужно купить.

## Что реально работает, а что нет

| Функция | Статус |
|---|---|
| Список версий из официального Version Manifest Mojang, поиск, фильтры (релизы/снапшоты/старые) | ✅ |
| Установка версии: client.jar, библиотеки, assets (проверка SHA-1, 8 потоков, прогресс) | ✅ |
| «Установлена» ставится только после загрузки **всех** файлов | ✅ |
| Fabric: профиль с meta.fabricmc.net, установка одной кнопкой | ✅ |
| Моды Sodium, Iris, Xaero's Minimap, JEI (+обязательные зависимости) с Modrinth | ✅ (Fabric) |
| Forge, NeoForge, OptiFine | ➖ кнопка «Сайт» — открывает официальную страницу (нужен Java для установщика; OptiFine нельзя раздавать напрямую) |
| Сборки: Vanilla+ (Fabric + моды), создание своей, удаление, управление .jar в сборке | ✅ |
| TechnoMagic / SkyBlock / RLCraft | ⚠️ создаётся изолированный профиль; модпаки CurseForge требуют API-ключ, моды не скачиваются |
| Настройки (RAM, разрешение, FPS, Java, JVM-аргументы, язык), хранение между запусками | ✅ (лимит FPS пишется в `options.txt`) |
| Язык интерфейса | ⚠️ только русский |
| Офлайн-профиль, ник, UUID, выбор скина/плаща (локальный предпросмотр) | ✅ |
| Вход Microsoft (официальный OAuth device code → Xbox → XSTS → Minecraft) | ⚠️ реализован, **не проверен**; нужен ваш Azure Client ID |
| Новости (официальный фид патчноутов Mojang), «Читать далее» | ✅ |
| Очистка кэша, папка игры, проверка обновлений (GitHub Releases) | ✅ |
| Формирование команды запуска (classpath, JVM/игровые аргументы, офлайн/MS-профиль) | ✅ |
| **Реальный запуск игры** | ❌ **нет Java-рантайма** — см. [docs/RUNTIME_INTEGRATION.md](docs/RUNTIME_INTEGRATION.md) |

Кнопка «ИГРАТЬ» не притворяется: она проверяет файлы, собирает настоящую команду запуска и, если рантайма нет,
честно говорит об этом и даёт скопировать команду.

## Сборка APK

### Через GitHub Actions (рекомендуется)
```bash
git remote add origin https://github.com/<вы>/MinecraftJavaLauncher.git
git push -u origin main
```
Откройте **Actions → Build APK → последний запуск → Artifacts**: `MinecraftJavaLauncher-debug` (и `-release`).
Тег `v1.0.0` (`git tag v1.0.0 && git push --tags`) дополнительно создаст GitHub Release с APK.

### Локально
Нужны JDK 17 и Android SDK (проще всего — открыть папку в Android Studio).
Gradle Wrapper в архив не входит: создайте его командой `gradle wrapper --gradle-version 8.10.2`
(или просто откройте проект в Android Studio), затем:
```bash
./gradlew :app:assembleDebug      # app/build/outputs/apk/debug/
```

## Вход через Microsoft
Нужен собственный Azure Client ID (Microsoft Entra → App registrations, public client, «Allow public client flows» = Yes).
Доступ к Minecraft Services для новых приложений Mojang выдаёт по заявке. Передайте ID при сборке:
`-PMS_CLIENT_ID=...` или секрет `MS_CLIENT_ID` в GitHub. Пароли не вводятся и не хранятся; токены лежат в приватном
хранилище приложения (DataStore, без шифрования).

## Структура
```
app/src/main/java/com/mclauncher/java/
├── core/        сеть (Http), пути, разбор version.json и правил Mojang
├── downloader/  Version Manifest, установка версий, Fabric
├── launcher/    команда запуска, интерфейс RuntimeBackend
├── auth/        офлайн-профиль, Microsoft OAuth
├── mods/        каталог модов, установка с Modrinth
├── builds/      сборки (instances/<id>)
├── news/        новости Mojang
├── settings/    DataStore
└── ui/          Compose-экраны, тема, компоненты
```
Модули Gradle не разделены: слои — это пакеты внутри `:app` (меньше шансов сломать сборку).

## Зависимости
Compose BOM 2024.10.01, Material 3, activity-compose, lifecycle (viewmodel/runtime-compose), DataStore Preferences,
core-ktx, kotlinx-coroutines-android. Больше ничего: JSON — `org.json` из Android, сеть — `HttpURLConnection`.

## Лицензии
Код лаунчера — MIT (файл LICENSE). Данные: Mojang (версии, ассеты, новости), FabricMC Meta, Modrinth API.
При подключении PojavLauncher-совместимого движка (LGPL-3.0) соблюдайте условия лицензии — см. docs.
